import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader, random_split
import numpy as np
import random
import matplotlib.pyplot as plt

from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, roc_curve, auc

from data_loader import get_patient_files, build_dataset
from model import CNN_LSTM


# ==============================
# SEED
# ==============================
def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

set_seed(42)


# ==============================
# SELECT PATIENT (IMPORTANT)
# ==============================
patient_id = "chb24"   # 🔥 use chb01–chb05

files = get_patient_files(patient_id)

print(f"\nTraining for patient: {patient_id}")
print(f"Files found: {len(files)}")

if len(files) == 0:
    print("❌ No files found")
    exit()


# ==============================
# LOAD DATA
# ==============================
X, y = build_dataset(files)

# 🔥 PER-SAMPLE NORMALIZATION (VERY IMPORTANT)
X = (X - np.mean(X, axis=(1,2,3), keepdims=True)) / \
    (np.std(X, axis=(1,2,3), keepdims=True) + 1e-8)

X = torch.tensor(X, dtype=torch.float32)
y = torch.tensor(y, dtype=torch.long)

dataset = TensorDataset(X, y)


# ==============================
# SPLIT (TRAIN / VAL / TEST)
# ==============================
train_size = int(0.7 * len(dataset))
val_size   = int(0.15 * len(dataset))
test_size  = len(dataset) - train_size - val_size

train_ds, val_ds, test_ds = random_split(
    dataset, [train_size, val_size, test_size]
)

train_loader = DataLoader(train_ds, batch_size=8, shuffle=True)
val_loader   = DataLoader(val_ds, batch_size=8)
test_loader  = DataLoader(test_ds, batch_size=8)


# ==============================
# DEVICE
# ==============================
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ==============================
# MODEL
# ==============================
model = CNN_LSTM().to(device)

class_counts = np.bincount(y.numpy(), minlength=2)
weights = 1.0 / torch.tensor(class_counts, dtype=torch.float32)
weights = weights / weights.sum()
weights = weights.to(device)

criterion = nn.CrossEntropyLoss(weight=weights)

optimizer = torch.optim.Adam(
    model.parameters(),
    lr=1e-4,
    weight_decay=1e-4
)

# ==============================
# EARLY STOPPING SETUP
# ==============================
epochs = 20
best_val_loss = float("inf")
patience = 5
counter = 0

train_losses = []
val_losses = []
train_accs = []
val_accs = []


# ==============================
# TRAINING
# ==============================
print("\n🚀 Training started...\n")

for epoch in range(epochs):

    # -------- TRAIN --------
    model.train()
    train_loss = 0
    correct = 0
    total = 0

    for xb, yb in train_loader:
        xb, yb = xb.to(device), yb.to(device)

        outputs = model(xb)
        loss = criterion(outputs, yb)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        train_loss += loss.item()

        _, pred = torch.max(outputs, 1)
        correct += (pred == yb).sum().item()
        total += yb.size(0)

    train_acc = 100 * correct / total

    train_losses.append(train_loss)
    train_accs.append(train_acc)


    # -------- VALIDATION --------
    model.eval()
    val_loss = 0
    correct = 0
    total = 0

    with torch.no_grad():
        for xb, yb in val_loader:
            xb, yb = xb.to(device), yb.to(device)

            outputs = model(xb)
            loss = criterion(outputs, yb)

            val_loss += loss.item()

            _, pred = torch.max(outputs, 1)
            correct += (pred == yb).sum().item()
            total += yb.size(0)

    val_acc = 100 * correct / total

    val_losses.append(val_loss)
    val_accs.append(val_acc)

    print(f"Epoch {epoch+1} | Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f} | Train Acc: {train_acc:.2f}% | Val Acc: {val_acc:.2f}%")


    # ==============================
    # 🔥 EARLY STOPPING (FORCE STOP)
    # ==============================
    if val_loss < best_val_loss:
        best_val_loss = val_loss
        counter = 0
        torch.save(model.state_dict(), "best_model.pth")
    else:
        counter += 1

    if counter >= patience:
        print("⛔ Early stopping triggered")
        break


# ==============================
# 📊 GRAPHS
# ==============================
plt.figure(figsize=(12,5))

plt.subplot(1,2,1)
plt.plot(train_losses, label="Train Loss")
plt.plot(val_losses, label="Val Loss")
plt.title("Loss Curve")
plt.legend()
plt.grid()

plt.subplot(1,2,2)
plt.plot(train_accs, label="Train Acc")
plt.plot(val_accs, label="Val Acc")
plt.title("Accuracy Curve")
plt.legend()
plt.grid()

plt.show()


# ==============================
# TEST
# ==============================
model.load_state_dict(torch.load("best_model.pth"))
model.eval()

correct = 0
total = 0

all_preds = []
all_labels = []
probs = []

with torch.no_grad():
    for xb, yb in test_loader:
        xb, yb = xb.to(device), yb.to(device)

        outputs = model(xb)
        prob = torch.softmax(outputs, dim=1)[:, 1]

        _, pred = torch.max(outputs, 1)

        correct += (pred == yb).sum().item()
        total += yb.size(0)

        all_preds.extend(pred.cpu().numpy())
        all_labels.extend(yb.cpu().numpy())
        probs.extend(prob.cpu().numpy())

test_acc = 100 * correct / total
print(f"\n✅ FINAL TEST ACCURACY: {test_acc:.2f}%")


# ==============================
# CONFUSION MATRIX
# ==============================
cm = confusion_matrix(all_labels, all_preds)

disp = ConfusionMatrixDisplay(cm, display_labels=["Interictal", "Preictal"])
disp.plot()
plt.show()


# ==============================
# ROC CURVE
# ==============================
fpr, tpr, _ = roc_curve(all_labels, probs)
roc_auc = auc(fpr, tpr)

plt.figure()
plt.plot(fpr, tpr, label=f"AUC = {roc_auc:.2f}")
plt.plot([0,1],[0,1],'--')
plt.legend()
plt.title("ROC Curve")
plt.grid()
plt.show()


# ==============================
# SAVE MODEL
# ==============================
torch.save(model.state_dict(), f"model_{patient_id}.pth")
print("💾 Model saved")