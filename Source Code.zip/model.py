import torch
import torch.nn as nn

class CNN_LSTM(nn.Module):
    def __init__(self):
        super(CNN_LSTM, self).__init__()

        # -----------------------
        # CNN FEATURE EXTRACTOR
        # -----------------------
        self.cnn = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=3, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(),
            nn.MaxPool2d(2),

            nn.Conv2d(16, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),

            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2),
        )

        # 🔥 Define once (correct)
        self.lstm = None

        self.dropout = nn.Dropout(0.5)
        self.fc = nn.Linear(128, 2)

    def forward(self, x):
        b, c, f, t = x.size()

        # Merge channels + freq
        x = x.view(b, 1, c * f, t)

        x = self.cnn(x)

        b, c, f, t = x.size()

        # Prepare for LSTM
        x = x.view(b, t, c * f)

        # 🔥 Create LSTM ONCE safely
        if self.lstm is None:
            self.lstm = nn.LSTM(
                input_size=c * f,
                hidden_size=64,
                num_layers=1,
                batch_first=True,
                bidirectional=True
            ).to(x.device)

        x, _ = self.lstm(x)

        # Last time step
        x = x[:, -1, :]

        x = self.dropout(x)
        x = self.fc(x)

        return x