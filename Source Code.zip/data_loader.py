import os
import numpy as np
import mne
from scipy.signal import stft

DATA_PATH = "data"

# ==============================
# FILE HANDLING
# ==============================
def get_seizure_files():
    file_path = os.path.join(DATA_PATH, "RECORDS-WITH-SEIZURES")
    seizure_files = []

    with open(file_path, "r") as f:
        for line in f:
            line = line.strip()
            if line.endswith(".edf"):
                seizure_files.append(os.path.join(DATA_PATH, line))

    return seizure_files


def get_patient_files(patient_id):
    files = get_seizure_files()
    return [f for f in files if os.path.basename(f).startswith(patient_id)]


# ==============================
# EEG LOADING + NORMALIZATION
# ==============================
def load_eeg(file_path):
    raw = mne.io.read_raw_edf(file_path, preload=True, verbose=False)

    # Bandpass filter
    raw.filter(0.5, 40)

    data = raw.get_data()

    # Channel-wise normalization
    data = (data - np.mean(data, axis=1, keepdims=True)) / \
           (np.std(data, axis=1, keepdims=True) + 1e-6)

    return data


# ==============================
# SEGMENTATION (10 sec window)
# ==============================
def segment_signal_with_time(data, fs=256, window_sec=10):
    window_size = window_sec * fs
    step = window_size // 2

    segments = []

    for i in range(0, data.shape[1] - window_size, step):
        start = i / fs
        end = (i + window_size) / fs
        segments.append((data[:, i:i+window_size], start, end))

    return segments


# ==============================
# SPECTROGRAM (clean frequency range)
# ==============================
def segment_to_spectrogram(segment):
    specs = []

    for ch in segment:
        f, t, Zxx = stft(
            ch,
            fs=256,
            nperseg=128,
            noverlap=64
        )

        # Keep EEG range (0.5–30 Hz)
        mask = (f >= 0.5) & (f <= 30)
        Zxx = np.abs(Zxx[mask])

        specs.append(Zxx)

    return np.array(specs)


# ==============================
# SEIZURE TIMES
# ==============================
def get_seizure_times(file_path):
    import re

    patient_folder = os.path.dirname(file_path)

    summary_file = None
    for f in os.listdir(patient_folder):
        if "summary" in f.lower():
            summary_file = os.path.join(patient_folder, f)
            break

    if summary_file is None:
        return []

    seizure_times = []
    file_name = os.path.basename(file_path)

    with open(summary_file, "r") as f:
        lines = f.readlines()

    inside = False

    for i in range(len(lines)):
        line = lines[i].strip()

        if file_name in line:
            inside = True

        if inside:
            if "Seizure Start Time" in line:
                start = float(re.findall(r'\d+', line)[0])
                end = float(re.findall(r'\d+', lines[i+1])[0])
                seizure_times.append((start, end))

            if "File Name" in line and file_name not in line:
                break

    return seizure_times


# ==============================
# 🔥 LABELING (10 min preictal)
# ==============================
def label_segment(start_time, seizure_times):
    for (sz_start, sz_end) in seizure_times:

        # 10 minutes before seizure
        if (sz_start - 1800) <= start_time < sz_start:
            return 1  # Preictal

    return 0  # Interictal


# ==============================
# 🔥 DATASET BUILDER (IMPROVED)
# ==============================
def build_dataset(files, max_files=10):
    X, y = [], []

    for file in files[:max_files]:
        print("\nProcessing:", file)

        data = load_eeg(file)
        seizure_times = get_seizure_times(file)

        if len(seizure_times) == 0:
            print("⚠️ Skipping (no seizure):", file)
            continue

        segments = segment_signal_with_time(data)

        for seg, start, end in segments:
            spec = segment_to_spectrogram(seg)
            label = label_segment(start, seizure_times)

            X.append(spec)
            y.append(label)

    X = np.array(X)
    y = np.array(y)

    # ==============================
    # SAFETY CHECK
    # ==============================
    if len(y) == 0:
        print("❌ No data created")
        return np.array([]), np.array([])

    class0 = np.where(y == 0)[0]
    class1 = np.where(y == 1)[0]

    if len(class1) == 0:
        print("❌ No seizure samples found")
        return np.array([]), np.array([])

    # ==============================
    # 🔥 SMART BALANCING
    # ==============================
    # Keep all seizure data
    # Limit non-seizure to 2x seizure
    keep_class0 = min(len(class0), len(class1))

    selected_class0 = np.random.choice(class0, keep_class0, replace=False)

    idx = np.concatenate([selected_class0, class1])
    np.random.shuffle(idx)

    X = X[idx]
    y = y[idx]

    print("\n✅ Dataset Ready")
    print("Samples:", len(X))
    print("Class distribution:", np.bincount(y))

    return X, y